package com.ideotic.edioticideas.nora;

/**
 * Created by Shubham on 16-05-2016.
 */
public class SingleRow{
        String priority;
        String title;
        String body;
        String id;

public SingleRow(String id,String priority, String title, String body) {
        this.priority = priority;
        this.title = title;
        this.body = body;
        }
        }
